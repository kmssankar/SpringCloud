package com.cts.products.priceservice.dto;

public class ItemPriceDTO {
	
	Double price;

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}
	
}
